package C_JavaAdvanced.JavaAdv.Generics.GenericSwapMethodInteger;

import C_JavaAdvanced.JavaAdv.Generics.GenericSwapMethodInteger.Box;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Box<Integer>> boxes = new ArrayList<>();

        while (n-- > 0) {
            Box<Integer> box = new Box<>(Integer.parseInt(scanner.nextLine()));
            boxes.add(box);

        }

        int first = scanner.nextInt();
        int second = scanner.nextInt();
        Collections.swap(boxes,first,second);

        for (Box<Integer> box : boxes) {
            System.out.println(box);
        }
    }

}
