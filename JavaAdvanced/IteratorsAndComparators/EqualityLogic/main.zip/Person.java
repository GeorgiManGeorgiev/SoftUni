package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.EqualityLogic;

public class Person implements Comparable<Person> {
    private String name;
    private int age;


    public Person(String name, int age) {
        this.name = name;
        this.age = age;

    }

    @Override
    public int hashCode(){
        return  17 * (this.name.hashCode()+Integer.hashCode(this.age)) ;
    }
    @Override
    public boolean equals(Object obj){
        Person other = (Person)obj;
       return this.name.equals(other.name) && this.age==other.age;
    }

    @Override
    public int compareTo(Person other) {
        int result = this.name.compareTo(other.name);
        if (result == 0) {
            result = this.age - other.age;
        }

        if (this.name.compareTo(other.name) == 0 && this.age - other.age == 0) {
            result = 0;
        }

        return result;
    }

    public int getAge() {
        return this.age;
    }

    @Override
    public String toString() {
        return this.name + " " + this.age;
    }

    public String getName() {
        return name;
    }
}

