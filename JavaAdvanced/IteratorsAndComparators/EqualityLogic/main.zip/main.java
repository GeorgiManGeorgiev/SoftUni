package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.EqualityLogic;

import java.util.*;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        Set<Person> treeSet = new TreeSet<>();
        Set<Person> hashSet = new HashSet<>();

        int count = Integer.parseInt(scanner.nextLine());
        while (count-->0) {
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);
            Person person = new Person(name, age);
            treeSet.add(person);
            hashSet.add(person);

        }

        System.out.println(treeSet.size());
        System.out.println(hashSet.size());

    }
}
