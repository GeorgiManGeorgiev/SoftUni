package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.EqualityLogic;

import java.util.Comparator;

public class PersonComparatorByName implements Comparator<Person> {
    @Override
    public int compare(Person f, Person s) {
        int result;
        if (f.getName().length() - s.getName().length() != 0) {
            result = f.getName().length() - s.getName().length();
        } else {
            char first = Character.toLowerCase(f.getName().charAt(0));
            char second = Character.toLowerCase(s.getName().charAt(0));
            result = first - second;
        }
        return result;
    }
}
