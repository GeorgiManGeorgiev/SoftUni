package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.CollectionEX;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;


public class ListyIterator implements Iterable<String>  {

    private List<String> elements;
    private int index;



    public ListyIterator(String... values){
    this.elements= Arrays.asList(values);
    this.index=0;
    }
    public boolean move(){
        if (this.index == this.elements.size()-1){
            return false;
        }
        this.index++;
        return true;
    }
    public void print(){
        if (this.elements.isEmpty()){
            System.out.println("Invalid Operation!");
        }else {
            System.out.println(this.elements.get(index));
        }
    }
    public boolean hasNext(){
        return index<elements.size()-1;
    }


    @Override
    public Iterator<String> iterator() {
        return new Iterator<String>() {
            int position=0;
            @Override
            public boolean hasNext() {
                return position <= elements.size()-1;
            }

            @Override
            public String next() {
                return elements.get(position++);
            }
        };
    }

    @Override
    public void forEach(Consumer<? super String> action) {

    }
}
