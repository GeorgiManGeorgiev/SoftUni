package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.CollectionEX;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] strings = Arrays.stream(scanner.nextLine().split("\\s+"))
                .skip(1)
                .toArray(String[]::new);

        ListyIterator listyIterator =  new ListyIterator(strings);

        String input = scanner.nextLine();
        while (!"END".equals(input)){


            switch (input){
                case "Move":
                    System.out.println(listyIterator.move());
                    break;
                case "Print":
                    listyIterator.print();
                    break;
                case "HasNext":
                    System.out.println(listyIterator.hasNext());
                    break;
                case"PrintAll":
                    Iterator<String> iterator = listyIterator.iterator();
                    while (iterator.hasNext()) {
                        System.out.print(iterator.next()+" ");
                    }
                    System.out.println();
                    break;

            }



            input=scanner.nextLine();
        }

    }
}
