package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.ListIteratorEX;

import java.util.Arrays;
import java.util.List;

public class ListyIterator {
    private List<String> elements;
    private int index;

    public ListyIterator(String... values){
    this.elements= Arrays.asList(values);
    this.index=0;
    }
    public boolean move(){
        if (this.index == this.elements.size()-1){
            return false;
        }
        this.index++;
        return true;
    }
    public void print(){
        if (this.elements.isEmpty()){
            System.out.println("Invalid Operation!");
        }else {
            System.out.println(this.elements.get(index));
        }
    }
    public boolean hasNext(){
        return index<elements.size()-1;
    }
}
