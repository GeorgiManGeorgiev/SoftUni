package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.Froggy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int[] stones = Arrays.stream(scanner.nextLine().split(", "))
                .mapToInt(Integer::parseInt).toArray();
        String command = scanner.nextLine();
        Lake lake = new Lake(stones);

        StringBuilder builder =new StringBuilder();

        for (Integer integer : lake) {
            builder.append(integer).append(", ");
        }





        String result = builder.toString();

        System.out.println(result.substring(0,result.lastIndexOf(",")));
    }
}
