package C_JavaAdvanced.JavaAdv.IteratorsAndComparators.ProblemStrategyPatternEX;

import java.util.*;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        Set<Person> peopleByAge = new TreeSet<>(new PersonComparatorByAge());
        Set<Person> peopleByName = new TreeSet<>(new PersonComparatorByName());

        int count = Integer.parseInt(scanner.nextLine());
        while (count-->0) {
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);
            Person person = new Person(name, age);
            peopleByAge.add(person);
            peopleByName.add(person);

        }

        for (Person person : peopleByName) {
            System.out.println(person.toString());
        }

        for (Person person : peopleByAge) {
            System.out.println(person.toString());
        }

    }
}
