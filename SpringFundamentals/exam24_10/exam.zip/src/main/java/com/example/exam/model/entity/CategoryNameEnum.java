package com.example.exam.model.entity;

public enum CategoryNameEnum {
    BATTLE, CARGO, PATROL
}
